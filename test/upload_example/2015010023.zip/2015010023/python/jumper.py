# DO NOT DELETE '__init__.py'
# Import modules


def jumper():
    # Read screenshot at './autojump.png'
    # You can also use any file in this directory at will
    pass

    # Process screenshot
    distance = 0
    pass

    # return distance as int
    return int(distance)
